using Microsoft.AspNetCore.Mvc;
using Project5ORM.Models.CodeFirst;

namespace Project5ORM.Controllers
{
    public class CategoriesController : Controller
    {
        private readonly CafeteriaEmployeesDBContext context;

        public CategoriesController(CafeteriaEmployeesDBContext context)
        {
            this.context = context;
        }

        public IActionResult Index()
        {
            var categories = context.Categories.ToList();
            return View(categories);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Category category)
        {
            if (!ModelState.IsValid)
            {
                return View(category);
            }

            context.Categories.Add(category); //Create
            context.SaveChanges(); //Save

            return RedirectToAction("Index");
        }
    }
}
